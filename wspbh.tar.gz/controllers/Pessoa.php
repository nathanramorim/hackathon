<?php
namespace controllers{
	/*
	Classe pessoa
	*/
	class Pessoa{
		//Atributo para banco de dados
		private $PDO;

		/*
		__construct
		Conectando ao banco de dados
		*/
		function __construct(){
			$this->PDO = new \PDO('mysql:host=localhost;dbname=api', 'root', '12345'); //Conexão
			$this->PDO->setAttribute( \PDO::ATTR_ERRMODE,\PDO::ERRMODE_EXCEPTION ); //habilitando erros do PDO
		}
		/*
		lista
		Listand pessoas
		*/
		public function lista(){
			global $app;
			$sth = $this->PDO->prepare("SELECT * FROM pessoa");
			$sth->execute();
			$result = $sth->fetchAll(\PDO::FETCH_ASSOC);
			$app->render('default.php',["data"=>$result],200); 
		}
		/*
		get
		param $id
		Pega pessoa pelo id
		*/
		public function get($id){
			global $app;
			$sth = $this->PDO->prepare("SELECT * FROM pessoa WHERE id = :id");
			$sth ->bindValue(':id',$id);
			$sth->execute();
			$result = $sth->fetch(\PDO::FETCH_ASSOC);
			$app->render('default.php',["data"=>$result],200); 
		}

		/*
		setData
		passa o Json para um array separado Pessoa | Endereço
		*/
		public function setData($dados)
		{
			foreach ($dados as $key => $value) :
					if (is_string($value)):
						$pessoa[$key] =$value;
					elseif (!is_string($value)):
						foreach ($value as $end):
							foreach ($end as $key=>$end_v):
								$endereco[$key]= $end_v;
							endforeach;
						endforeach;
					endif;
			endforeach;
			$data ['pessoa'] = $pessoa;
			$data ['endereco'] = $endereco;
			return $data;
		}

		/*
		nova
		Cadastra pessoa
		*/
		public function nova(){
			global $app;
			$dados = json_decode($app->request->getBody(), true);
			$dados = (sizeof($dados)==0)? $_POST : $dados;
			$keys = array_keys($dados); //Paga as chaves do array
			
			/*passando o Json para um array separado Pessoa | Endereço*/
			$data = $this->setData($dados);

			/*Separando o nome dos campos para pessoa*/
			foreach ($keys as $title):
				if ($title != 'address'):
					$keys_pe[] = $title;
				endif;
			endforeach;
			
			/*Separando o nome dos campos para endereço*/
			foreach ($dados['address'] as $end):
				foreach ($end as $title=>$b):
					$end_k[] = $title;
				endforeach;
			endforeach;
			
			/*
			O uso de prepare e bindValue é importante para se evitar SQL Injection
			*/
			$sth = $this->PDO->prepare("INSERT INTO pessoa (".implode(',', $keys_pe).") VALUES (:".implode(",:", $keys_pe).")");
			$end_sth = $this->PDO->prepare("INSERT INTO endereco (id_pessoa_fk,".implode(',', $end_k).") VALUES (:id_pessoa_fk,:".implode(",:", $end_k).")");
			
			/*bind pessoa*/
			foreach ($data['pessoa'] as $key => $value):
				if ($key == 'password'):
					$sth->bindValue(':'.$key,sha1($value));
				else:
					$sth->bindValue(':'.$key,$value);
				endif;
			endforeach;
			
			$return = $sth->execute();

			/* validação se usuário foi inserido para então inserir endereço*/
			if($return):
				$id = $this->PDO->lastInsertId();
				$end_sth ->bindValue(':id_pessoa_fk',$id);
			endif;
			
			/*bind endereço*/
			foreach ($data['endereco'] as $key => $value):
				$end_sth ->bindValue(':'.$key,$value);
			endforeach;			

			$end_sth->execute();

			//Retorna o id inserido
			$id = $app->render('default.php',["data"=>['id'=>$this->PDO->lastInsertId()]],200); 
		}

		/*
		editar
		param $id
		Editando pessoa
		*/
		public function editar($id){
			global $app;
			$dados = json_decode($app->request->getBody(), true);
			$dados = (sizeof($dados)==0)? $_POST : $dados;
			$sets = [];
			foreach ($dados as $key => $VALUES) {
				$sets[] = $key." = :".$key;
			}

			$sth = $this->PDO->prepare("UPDATE pessoa SET ".implode(',', $sets)." WHERE id = :id");
			$sth ->bindValue(':id',$id);
			foreach ($dados as $key => $value) {
				$sth ->bindValue(':'.$key,$value);
			}
			//Retorna status da edição
			$app->render('default.php',["data"=>['status'=>$sth->execute()==1]],200); 
		}

		/*
		excluir
		param $id
		Excluindo pessoa
		*/
		public function excluir($id){
			global $app;
			$sth = $this->PDO->prepare("DELETE FROM pessoa WHERE id = :id");
			$sth ->bindValue(':id',$id);
			$app->render('default.php',["data"=>['status'=>$sth->execute()==1]],200); 
		}
	}
}